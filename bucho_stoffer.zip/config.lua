cfg = {}

--Items--

--math--





--Marker--

cfg.MarkerID = 29 --(Standard dollar tegn)
cfg.Hojde = 0.80 --(Standard 0.80)
cfg.Laengde = 0.80 --(Standard 0.80)

--Drawtext3d--

cfg.Text = "~w~[~g~E~w~] Sælg Stoffer" --(Standard "~w~[~g~E~w~] Sælg Stoffer")
cfg.TextStoerlse1 = 0.5 --(Standard 0.5)
cfg.TextStoerlse2 = 0.4 --(Standard 0.4)
cfg.Font = 4 --(Standard 4) 

--FONT LIST--
--[[ 

Font 1 is Sign Painter
Font 2 no idea, some sort of slab serif type
Font 4-6 is Chalet Comprimé - Cologne 1960
Font 7 is a slightly modified version of the classic Pricedown


]]--